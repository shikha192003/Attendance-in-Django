from django.shortcuts import render,HttpResponse,redirect
from attendence_app.models import Attendence
from datetime import date
# Create your views here.
def home(request):
    datas={
        # 'student':Attendence.objects.filter(date=date.today()),
        'student':Attendence.objects.all(),
        'date':date.today()
    }
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        address=request.POST.get('address')
        tdate=date.today()
        data=Attendence(name=name,email=email,phone=phone,address=address,date=tdate)
        data.save()
    return render(request,'index.html',datas)
    # return HttpResponse('page is ready to use...!')
    
def delete(request,id):
    Attendence.objects.filter(id=id).delete()
    return redirect('/')

def edit(request,id):
    student={
        'id':Attendence.objects.get(id=id).id,
        'name':Attendence.objects.get(id=id).name,
        'email':Attendence.objects.get(id=id).email,
        'phone':Attendence.objects.get(id=id).phone,
        'address':Attendence.objects.get(id=id).address,
        'date':Attendence.objects.get(id=id).date,
        
    
    }
    if request.method=="POST":
        id=request.POST.get('id')
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        address=request.POST.get('address')
        tdate=request.POST.get('date')
        datas=Attendence(id=id,name=name,email=email,phone=phone,address=address,date=tdate)
        datas.save()
        return redirect('/')
    return render(request,'edit.html',student)