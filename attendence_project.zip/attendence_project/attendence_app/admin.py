from django.contrib import admin
from attendence_app.models import Attendence
# Register your models here.
admin.site.register(Attendence)
